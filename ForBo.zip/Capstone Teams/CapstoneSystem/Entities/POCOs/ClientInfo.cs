﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapstoneSystem.Entities.POCOs
{
    public class ClientInfo
    {
        public int ClientId { get; set; }
        public string Company { get; set; }
    }
}
