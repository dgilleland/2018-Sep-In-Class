﻿namespace CapstoneSystem.Entities.POCOs
{
    public class StudentAssignment
    {
        public int ClientId { get; set; }
        public int StudentId { get; set; }
        public string TeamLetter { get; set; }
    }
}
