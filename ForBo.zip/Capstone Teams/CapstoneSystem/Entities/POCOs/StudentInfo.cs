﻿namespace CapstoneSystem.Entities.POCOs
{
    public class StudentInfo
    {
        public int StudentId { get; set; }
        public string FullName { get; set; }
    }
}
