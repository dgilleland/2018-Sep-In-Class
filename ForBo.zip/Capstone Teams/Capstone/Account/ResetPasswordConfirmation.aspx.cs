﻿using System.Web.UI;

namespace Capstone.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}